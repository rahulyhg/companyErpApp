<?php
class page_companyERP_page_owner_main extends page_componentBase_page_owner_main{
	function init(){
		 parent::init();


		
	}
} 