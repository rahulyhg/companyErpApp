
<?php
namespace companyERP;
class Model_Master_Paymentpaid extends Model_Master_Transaction{
	public $table="companyERP_paymentpaid";
	function init(){
		parent::init();

		$this->addCondition('Transaction_type','paymentpaid');

		
	}
}